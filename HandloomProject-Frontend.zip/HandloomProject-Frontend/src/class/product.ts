export class Product {
    productid:number;
    pname:string;
    price:number;
    
    img : string
    constructor(productid:number, pname:string, price:number , img : string) {
        //    this.productid=productid;
        //    this.pname=pname;
        //    this.price=price;
        //    this.img=img;
          
    }
}
