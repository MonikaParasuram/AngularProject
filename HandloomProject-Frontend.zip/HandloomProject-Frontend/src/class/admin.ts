export class Admin {
username: string;
adminName:string;
adminpassword: any;
    constructor(adminId:number, adminName:string, adminPhone:string, username:string, adminpassword:string) {
          
    }
}
